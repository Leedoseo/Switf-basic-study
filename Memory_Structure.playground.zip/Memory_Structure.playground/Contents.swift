import UIKit

struct Korean {
    static let country = "Korea"    // static 변수(상수)로 데이터 영역에 할당
}

var name: String?                   // 전역 변수로 데이터 영역에 할당
var age: Int?                       // 전역 변수로 데이터 영역에 할당
func fetchDate() {
    
}

func add(_ a: Int, _ b: Int) -> Int {   // 파라미터 a, b는 스택에 할당됨
    let result = a + b                  // 지역변수 result는 스택에 할당됨
    return result
}
